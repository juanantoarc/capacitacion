# capacitacion
desarrollo en visual estudio
